<?php
// Database configuration variables
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "crimealert";

// Establish the mysqli connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check for connection errors
if ($conn->connect_error) 
{
    // Ensure the error message is clear for debugging
    die("Database connection failed: " . $conn->connect_error);
}

// Set charset to handle special characters correctly in MVC
mysqli_set_charset($conn, "utf8mb4");
?>