<?php
// Management/User/MVC/php/home_controller.php

// In MVC, the controller initiates the session if needed and loads the view
session_start();

// Load the HTML View file
include "../html/home_view.php";
?>